<?php

// Start of Zend Debugger v.

function debugger_print() {}

function get_call_stack() {}

function debugger_start_debug() {}

function debugger_connector_pid() {}

function debugger_connect() {}

function debugger_get_server_start_time() {}

// End of Zend Debugger v.
