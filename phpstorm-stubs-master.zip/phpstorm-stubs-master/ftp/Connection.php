<?php

namespace FTP;

/**
 * @since 8.1
 */
final class Connection {}
