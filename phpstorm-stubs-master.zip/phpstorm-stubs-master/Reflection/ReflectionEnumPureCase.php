<?php

/**
 * @link https://php.net/manual/en/class.reflectionenumpurecase.php
 * @since 8.1
 */
class ReflectionEnumPureCase extends ReflectionClassConstant {}
