<?php

namespace RdKafka;

class Exception extends \Exception {}
