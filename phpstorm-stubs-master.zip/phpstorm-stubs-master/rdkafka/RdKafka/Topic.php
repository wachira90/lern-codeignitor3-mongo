<?php

namespace RdKafka;

abstract class Topic
{
    /**
     * @return string
     */
    public function getName() {}
}
