<?php

namespace LDAP;

/**
 * @since 8.1
 */
final class Result {}
