<?php

namespace parallel\Runtime\Error;

use parallel\Runtime\Error;

class Closed extends Error {}
