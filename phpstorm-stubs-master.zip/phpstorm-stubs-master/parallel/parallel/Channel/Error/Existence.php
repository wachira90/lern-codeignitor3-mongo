<?php

namespace parallel\Channel\Error;

use parallel\Channel\Error;

class Existence extends Error {}
