<?php

namespace parallel\Events\Input\Error;

use parallel\Events\Input\Error;

class IllegalValue extends Error {}
