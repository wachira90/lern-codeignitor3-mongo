<?php

namespace parallel\Events;

class Error extends \parallel\Error {}
