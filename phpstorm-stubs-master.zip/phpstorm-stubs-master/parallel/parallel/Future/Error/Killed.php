<?php

namespace parallel\Future\Error;

use parallel\Error;

class Killed extends Error {}
