<?php

namespace IMAP;

/**
 * @since 8.1
 */
final class Connection {}
