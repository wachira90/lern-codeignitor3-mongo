<?php

// Stub for ext-meminfo: https://github.com/BitOne/php-meminfo

/**
 * @param resource $stream
 *
 * @return void
 */
function meminfo_dump($stream) {}
