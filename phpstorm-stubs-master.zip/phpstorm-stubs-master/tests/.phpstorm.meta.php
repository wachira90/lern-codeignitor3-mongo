<?php
namespace PHPSTORM_META {
    override(\StubTests\TestData\Providers\EntitiesFilter::getFiltered(0), type(0));
}
